@extends('_templates.main')

@section('content')

<div class="row">


</div>

<script>
	$(document).ready(function() {
		// getDataDashboard();
	});
</script>

@endsection